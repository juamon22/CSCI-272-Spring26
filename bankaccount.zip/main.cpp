#include "BankAccount.h"
#include <iostream>
using namespace std;

int main(){
    BankAccount bankAccount1;
    
    bankAccount1.deposit(30.5);
    
    cout << "Account Balance: $"<< bankAccount1.getBalance() << endl;

    return 0;
}