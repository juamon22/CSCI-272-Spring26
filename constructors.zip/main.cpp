#include "Car.h"

int main(){
    
    Car car1;
    
    Car car2("Tesla", "X", 2022);
    
    Car car3(car2);
    
    Car* pCar1 = new Car;
    
    Car* pCar2 = new Car("Tesla", "X", 2022);
    
    Car carArray[20];
    
    car1.startEngine();
    car2.startEngine();
    car3.startEngine();
    pCar1->startEngine();
    pCar2->startEngine();
    carArray[0].startEngine();
    
    delete pCar1;
    delete pCar2;

    return 0;
}