#include "User.h"

int main(){
    
    User user1("userName123", "password123");
    
    bool success = user1.login("userName1234", "password123");
    
    if (success){
        cout<<"User logged in successfully!"<<endl;
    } else {
        cout << "Login failed. Please check your credentials and try again."<<endl;
    }

    return 0;
}